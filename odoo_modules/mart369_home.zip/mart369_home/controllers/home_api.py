"""The endpoint the 369 Mart app reads its home page from.

Deliberately type='http' returning a plain JSON body, not type='json'. In
Odoo 19 type='json' is a deprecated alias for 'jsonrpc', which only accepts
POST and wraps everything in a {"jsonrpc": "2.0", "result": ...} envelope the
app would have to unwrap. A browser fetch() wants a GET and a bare object.
"""

from odoo import http
from odoo.http import request

# The shape lives in the base now: the product page and the catalogue import it
# too, and a route decorator should not need a home page installed.
from odoo.addons.mart369.controllers.public import _PUBLIC_JSON


class Mart369HomeApi(http.Controller):

    @http.route('/369mart/home', **_PUBLIC_JSON)
    def home(self, **kwargs):
        """The whole home page, both modes.

        Shape: {"quick": {tabs, banners, categories, sections, freeDeliveryAt},
                "all": {...}}
        """
        config = request.env['mart369.config'].sudo()._get()
        return self._respond(config._serialize_modes(), config)

    @http.route('/369mart/home/<string:mode_key>', **_PUBLIC_JSON)
    def home_mode(self, mode_key, **kwargs):
        """One mode only, for a client that loads the second tab later."""
        config = request.env['mart369.config'].sudo()._get()
        mode = request.env['mart369.home.mode'].sudo()._get(mode_key)
        if not mode or not mode.active:
            return request.make_json_response(
                {'error': 'unknown_mode', 'mode': mode_key}, status=404)
        return self._respond(mode._serialize(), config)

    @http.route('/369mart/home/health', **_PUBLIC_JSON)
    def health(self, **kwargs):
        """A cheap check that the module is installed and configured."""
        config = request.env['mart369.config'].sudo()._get()
        return request.make_json_response({
            'ok': True,
            'modes': config.mode_ids.filtered('active').mapped('key'),
        })

    def _respond(self, payload, config):
        # Do not set Access-Control-Allow-Origin here. Odoo already set it from
        # cors='*' above, and the response headers are extended rather than
        # replaced - setting it again emits it twice and browsers reject that.
        # The app loads this feed on every screen, so it is where the shop
        # says what its money looks like. The app used to print a rupee sign
        # in front of whatever number it held, whatever the shop was pricing
        # in.
        payload = dict(payload, currency=request.env['mart369.serializable']
                       .sudo()._mart369_shop_currency())
        max_age = max(config.cache_seconds or 0, 0)
        return request.make_json_response(payload, headers=[
            ('Cache-Control', 'public, max-age=%d' % max_age),
        ])
