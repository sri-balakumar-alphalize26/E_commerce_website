from . import test_home_api
from . import test_builder
from . import test_version
from . import test_admin_api
from . import test_page_trash
from . import test_starter
from . import test_row_picker
