from . import test_auth_api
from . import test_phone
from . import test_customers
from . import test_admin_customers
from . import test_customer_crm
from . import test_phone_signin
