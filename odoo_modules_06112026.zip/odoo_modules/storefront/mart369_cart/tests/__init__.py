from . import test_cart_api
from . import test_admin_coupons
from . import test_deals
from . import test_admin_delivery
from . import test_coupon_desk
from . import test_branch_quick
from . import test_sample_coupons
